const users = [
  {
    userPic: "/images/Avatar0.png",
    name: "Abel",
    email: "abel@mit.edu",
    password: "secret",
    balance: 100,
    transactionHistory: [],
  },
];

export default users;
